default['installed_software']['7zip']['version'] = 3.1
default['installed_software']['7zip']['installation_date'] = 13.11
default['installed_software']['7zip']['installed'] = true
