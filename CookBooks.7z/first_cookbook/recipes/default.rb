#
# Cookbook:: first_cookbook
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

file 'C:\\test.txt' do
  content 'This is the first run'
  #owner  'root'
  #group  'root'
  #mode '0755'
  action :create
end

arch = node['kernel']['machine']

if arch == 'i386'
  file 'C:\\chef_arch_test.txt' do
    content '32bit'
    action :create
  end
  log
elsif arch == 'x86_64'
file 'C:\\chef_arch_test.txt' do
  content '64bit'
  action :create
  end
end

log "This is a test run on machine #{arch}" do
  level :info
end
log "Registered User is: #{registered_user}" do
  level :info
end
