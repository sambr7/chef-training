#
# Cookbook:: kitchen_test
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

case node['platform_family']
when 'windows'
 windows_package 'Install 7-Zip 9.20 (x64 edition)' do
   package_name '7-Zip 9.20 (x64 edition)'
   source 'https://www.7-zip.org/a/7z1805-x64.msi'
   action :install
   returns [0, 42, 127]
 end
end
