file_cache_path "C:\\Users\\SamuelJanuario\\Documents\\IBM\\Trainings\\Chef\\CookBooks"
cookbook_path "C:\\Users\\SamuelJanuario\\Documents\\IBM\\Trainings\\Chef\\CookBooks"
